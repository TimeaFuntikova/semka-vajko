package com.api.semestralProjectVajko;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SemestralProjectVajkoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SemestralProjectVajkoApplication.class, args);
	}

}
