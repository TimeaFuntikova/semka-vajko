package com.api.semestralProjectVajko;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SemestralProjectVajkoApplicationTests {

	@Test
	void contextLoads() {
	}

}
